# injure4dancer Assistant
A mobile application designed to Elevate Your Wellness Journey. Your Dedicated Wellness Companion.Effortlessly monitor your injuries and discover tailored care suggestions. Immerse yourself in 3D interactive models for a comprehensive grasp of your injuries.

## Note :  
  - **This is for instructors to prepare ONLY**

  - **Don't show the curriculum to students**
  
  - **Do not lead the class by simply following the curriculum**
  
  - **Who to contact for technical support: Marisabel**
    
## Prerequisite
To use the OpenAI feature, please create .env file. Check [.env.example](https://github.com/cm-st-project/injure4dancer_assistant/blob/main/assets/.env.example) as a reference
1. In the `assets/.env` file, replace the `YOUR_OPENAI_API_KEY` variable with your actual OpenAI API
   key.


