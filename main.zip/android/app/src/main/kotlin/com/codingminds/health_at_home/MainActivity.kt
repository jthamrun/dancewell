package com.codingminds.health_at_home

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
